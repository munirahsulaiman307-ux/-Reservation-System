/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservation;

/**
 * Hotel room item that can be booked.
 */
  public class HotelRoom extends ReservableItem implements Bookable {
       /** Room type (e.g. Single, Double, Suite). */
  private String roomType;
  /** Capacity (number of guests). */
  private Integer capacity;
 /** Default constructor. */
  public HotelRoom() {
  super();
  this.roomType = "";
  this.capacity = 1;
  }
/**
     * Full constructor.
     * @param itemID id
     * @param name name
     * @param roomType type
     * @param capacity capacity
     */
  public HotelRoom(Integer itemID, String name, String roomType, Integer capacity) {
  super(itemID, name);
  this.roomType = roomType;
  this.capacity = capacity;
  }
 /**
     * Gets the roomType.
     *
     * @return roomType
     */
  public String getRoomType() {
  return roomType;
  }
/** @param roomType set roomType. */

  public void setRoomType(String roomType) {
  this.roomType = roomType;
  }
/**
     * Gets the capacity.
     *
     * @return capacity
     */
  public Integer getCapacity() {
  return capacity;
  }
/** @param capacity set capacity. */

  public void setCapacity(Integer capacity) {
  this.capacity = capacity;
  }

  @Override
  public String displayDetails() {
  return String.format("HotelRoom - %s | Type:%s | Cap:%s | Avail:%s",
  getName(), roomType, capacity, isAvailable());
  }

  @Override
  public String toString() {
  return "HotelRoom: " + displayDetails();
  }

  @Override
  public void book(Customer customer) throws ItemNotFoundException {
  if (!isAvailable()) {
  throw new ItemNotFoundException("Room is already booked: " + getItemID());
  }
  setAvailable(false);
  Reservation r = new Reservation(customer, this);
  customer.addReservation(r);
  }

  @Override
  public void cancelBooking(Customer customer) throws ItemNotFoundException {
  boolean removed = customer.removeReservationForItem(this);
  if (!removed) {
  throw new ItemNotFoundException("No booking found to cancel for item " + getItemID());
  }
  setAvailable(true);
  }
  }
