/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservation;

/**
 * Demo driver for ReservationSystem.
 * Run Main to see sample flows.
 */
public class Main {
    public static void main(String[] args) {
        ReservationSystem sys = new ReservationSystem();

        // Create items
        Flight f1 = new Flight(101, "Flight A123", "Riyadh", "SaudiAir");
        Flight f2 = new Flight(102, "Flight B456", "Jeddah", "FlyHigh");
        HotelRoom r1 = new HotelRoom(201, "Room 101", "Single", 1);
        EventSeat s1 = new EventSeat(301, "Seat VIP-1", "VIP");

        // Add to catalog
        sys.addItem(f1);
        sys.addItem(f2);
        sys.addItem(r1);
        sys.addItem(s1);

        // Create customers
        Customer c1 = new Customer(1, "Ahmed");
        Customer c2 = new Customer(2, "Laila");

        sys.registerCustomer(c1);
        sys.registerCustomer(c2);

        // Demonstrate bookings
        try {
            System.out.println("Booking Flight 101 for Ahmed...");
            sys.bookItem(1, 101); // ok

            System.out.println("Attempt booking Flight 101 for Laila (should raise)...");
            sys.bookItem(2, 101); // already booked -> exception
        } catch (ItemNotFoundException ex) {
            System.out.println("Exception caught: " + ex.getMessage());
        }

        // Cancel booking
        try {
            System.out.println("Cancel booking Flight 101 by Ahmed...");
            sys.cancelBooking(1, 101);
        } catch (ItemNotFoundException ex) {
            System.out.println("Cancel exception: " + ex.getMessage());
        }

        // Book again after cancel (should succeed)
        try {
            System.out.println("Book Flight 101 for Laila now...");
            sys.bookItem(2, 101);
        } catch (ItemNotFoundException ex) {
            System.out.println("Unexpected: " + ex.getMessage());
        }

        // Show items sorted
        System.out.println("\nCatalog before sorting:");
        for (ReservableItem it : sys.getCatalog()) System.out.println(it);

        sys.sortCatalogByName();

        System.out.println("\nCatalog after sorting (by name):");
        for (ReservableItem it : sys.getCatalog()) System.out.println(it);

        // Show customer's reservations
        System.out.println("\nLaila's reservations:");
        Customer found = sys.findCustomerById(2);
        if (found != null) {
            for (Reservation r : found.getReservations()) {
                System.out.println(r);
            }
        }

        // Demonstrate equals (two items with same ID)
        System.out.println("\nDemonstrate equals():");
        Flight duplicate = new Flight(101, "Fake Flight", "Nowhere", "NoAir");
        System.out.println("f1.equals(duplicate) => " + f1.equals(duplicate));

        // Try to delete customer with active reservation
        System.out.println("\nAttempting to delete Laila (has active reservations)...");
        boolean deleted = sys.deleteCustomer(2);
        System.out.println("Deleted? " + deleted);

        // Cancel Laila's reservation, then delete
        try {
            sys.cancelBooking(2, 101);
        } catch (ItemNotFoundException ex) {
            System.out.println("Cancel error: " + ex.getMessage());
        }

        System.out.println("Attempting to delete Laila again...");
        deleted = sys.deleteCustomer(2);
        System.out.println("Deleted? " + deleted);

        // Clone customer example
        System.out.println("\nCloning Ahmed (c1)...");
        Customer c1Clone = c1.clone();
        System.out.println("Original: " + c1);
        System.out.println("Clone:    " + c1Clone);
    }
}
