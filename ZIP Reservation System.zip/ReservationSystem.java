/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;

/**
 * Main reservation system that manages items and customers.
 */
public class ReservationSystem {

    /** Catalog of reservable items. */
    private List<ReservableItem> catalog;

    /** Registered customers (TreeSet for ordering by id). */
    private TreeSet<Customer> customers;

    /** Default constructor. */
    public ReservationSystem() {
        catalog = new ArrayList<>();
        customers = new TreeSet<>();
    }

    /**
     * Add an item to the catalog.
     * @param item item to add
     */
    public void addItem(ReservableItem item) {
        catalog.add(item);
    }

    /**
     * Register a new customer.
     * @param c customer
     */
    public void registerCustomer(Customer c) {
        customers.add(c);
    }

    /**
     * Find customer by id.
     * @param id customer id
     * @return Customer or null
     */
    public Customer findCustomerById(Integer id) {
        for (Customer c : customers) {
            if (c.getId() != null && c.getId().equals(id)) return c;
        }
        return null;
    }

    /**
     * Find item by id.
     * @param itemID item id
     * @return ReservableItem or null
     */
    public ReservableItem findItemById(Integer itemID) {
        for (ReservableItem i : catalog) {
            if (i.getItemID() != null && i.getItemID().equals(itemID)) return i;
        }
        return null;
    }

    /** @return catalog list. */
    public List<ReservableItem> getCatalog() {
        return catalog;
    }

    /** Sort catalog by name. */
    public void sortCatalogByName() {
        Collections.sort(catalog);
    }

    /**
     * Delete a customer if they have no active reservations.
     * @param id customer id
     * @return true if deleted
     */
    public boolean deleteCustomer(Integer id) {
        Customer c = findCustomerById(id);
        if (c == null) return false;
        if (c.hasActiveReservations()) return false;
        return customers.remove(c);
    }

    /**
     * Book an item for a customer, with checks and exceptions.
     * @param customerId customer id
     * @param itemId item id
     * @throws ItemNotFoundException if any check fails
     */
    public void bookItem(Integer customerId, Integer itemId) throws ItemNotFoundException {
        Customer c = findCustomerById(customerId);
        if (c == null) {
            throw new ItemNotFoundException("Customer not found: " + customerId);
        }
        ReservableItem item = findItemById(itemId);
        if (item == null) {
            throw new ItemNotFoundException("Item not found: " + itemId);
        }
        if (!(item instanceof Bookable)) {
            throw new ItemNotFoundException("Item is not bookable: " + itemId);
        }
        ((Bookable) item).book(c);
    }

    /**
     * Cancel an existing booking.
     * @param customerId customer id
     * @param itemId item id
     * @throws ItemNotFoundException if any check fails
     */
    public void cancelBooking(Integer customerId, Integer itemId) throws ItemNotFoundException {
        Customer c = findCustomerById(customerId);
        ReservableItem item = findItemById(itemId);
        if (c == null) throw new ItemNotFoundException("Customer not found: " + customerId);
        if (item == null) throw new ItemNotFoundException("Item not found: " + itemId);
        if (!(item instanceof Bookable)) throw new ItemNotFoundException("Item not bookable.");
        ((Bookable) item).cancelBooking(c);
    }
}
