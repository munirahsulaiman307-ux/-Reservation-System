/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservation;

/**
 * Custom exception for not-found or invalid booking operations.
 */
public class ItemNotFoundException extends Exception {

    /**
     * @param message detailed message
     */
    public ItemNotFoundException(String message) {
        super(message);
    }
}
