/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservation;

import java.util.Objects;

/**
 * Flight item that can be booked.
 */
  public class Flight extends ReservableItem implements Bookable {
      /** Destination city or code. */
  private String destination;
  /** Airline name. */
  private String airline;
  /** Default constructor. */
  public Flight() {
  super();
  this.destination = "";
  this.airline = "";
  }
  /**
     * Full constructor.
     * @param itemID id
     * @param name name
     * @param destination destination
     * @param airline airline
     */   
  public Flight(int itemID, String name, String destination, String airline) {
  super(itemID, name);
  this.destination = destination;
  this.airline = airline;
  }
 /**
     * Gets the destination.
     *
     * @return destination
     */
  public String getDestination() {
  return destination;
  }
 /** @param destination set destination. */
  public void setDestination(String destination) {
  this.destination = destination;
  }
  /**
     * Gets the airline.
     *
     * @return airline
     */
  public String getAirline() {
  return airline;
  }
 /** @param airline set airline. */
  public void setAirline(String airline) {
  this.airline = airline;
  }

  @Override
  public String displayDetails() {
  return String.format("Flight - %s | Dest:%s | Airline:%s | Avail:%s",
  getName(), destination, airline, isAvailable());
  }

  @Override
  public String toString() {
  return "Flight: " + displayDetails();
  }

  @Override
  public void book(Customer customer) throws ItemNotFoundException {
  if (!isAvailable()) {
  throw new ItemNotFoundException("Flight is already booked: " + getItemID());
  }
  setAvailable(false);
  // create reservation and add to customer
  Reservation r = new Reservation(customer, this);
  customer.addReservation(r);
  }

  @Override
  public void cancelBooking(Customer customer) throws ItemNotFoundException {
  boolean removed = customer.removeReservationForItem(this);
  if (!removed) {
  throw new ItemNotFoundException("No booking found to cancel for item " + getItemID() + " by customer " + customer.getId());
  }
  setAvailable(true);
  }

  @Override
  public boolean equals(Object o) {
  return super.equals(o);
  }

  @Override
  public int hashCode() {
  return Objects.hash(super.hashCode(), destination, airline);
  }
  }
