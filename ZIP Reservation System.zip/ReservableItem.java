/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package reservation;

import java.util.Objects;

/**
 * Abstract base class for items that can be reserved.
 * Contains common fields: itemID, name, available.
 */
  public abstract class ReservableItem implements Comparable<ReservableItem> {
      /** Item identifier (wrapper Integer). */
  private Integer itemID; // wrapper class as required
  /** Item name or title. */
  private String name;
  /** Availability flag: true = available. */
  private boolean available;
  /** Default constructor. */
  public ReservableItem() {
  this.itemID = null;
  this.name = "";
  this.available = true;
  }
   /**
     * Constructor with id and name.
     * @param itemID item id
     * @param name item name
     */

  public ReservableItem(Integer itemID, String name) {
  this.itemID = itemID;
  this.name = name;
  this.available = true;
  }
  /**
     * Gets the item ID.
     *
     * @return item ID
     */

  public Integer getItemID() {
  return itemID;
  }
  /** @param itemID set item ID. */
  public void setItemID(Integer itemID) {
  this.itemID = itemID;
  }
   /**
     * Gets the item name.
     *
     * @return item name
     */

  public String getName() {
  return name;
  }
 /** @param name set item name. */
  public void setName(String name) {
  this.name = name;
  }
   /**
     * Checks whether this item is Available.
     *
     * @return true if Available, false otherwise
     */

  public boolean isAvailable() {
  return available;
  }
 /** @param available set availability. */
  public void setAvailable(boolean available) {
  this.available = available;
  }

   /**
     * Subclasses provide their display details.
     * @return details string
     */
    public abstract String displayDetails();

  @Override
  public String toString() {
  return String.format("ID:%s | Name:%s | Available:%s",
  itemID, name, available);
  }

   /**
     * Equality based on itemID.
     * @param o other object
     * @return true if IDs equal
     */
    @Override
    public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof ReservableItem)) return false;
    ReservableItem that = (ReservableItem) o;
    return Objects.equals(itemID, that.itemID);
    }

  @Override
  public int hashCode() {
  return Objects.hash(itemID);
  }

  /**
     * Compare by name (alphabetical, case-insensitive).
     * @param other other item
     * @return compare value
     */
    @Override
    public int compareTo(ReservableItem other) {
    if (this.name == null) return -1;
    if (other == null || other.name == null) return 1;
    return this.name.compareToIgnoreCase(other.name);
    }
    }
