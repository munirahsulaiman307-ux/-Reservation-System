/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservation;

/**
 * Event seat item that can be booked.
 */
  public class EventSeat extends ReservableItem implements Bookable {
       /** Seat category (VIP, Regular, etc.). */
  private String category;
  
/** Default constructor. */
  public EventSeat() {
  super();
  this.category = "";
  }
/**
     * Full constructor.
     * @param itemID id
     * @param name name
     * @param category category
     */
  public EventSeat(Integer itemID, String name, String category) {
  super(itemID, name);
  this.category = category;
  }
/**
     * Gets the category.
     *
     * @return category
     */
  public String getCategory() {
  return category;
  }
/** @param category set category. */
  public void setCategory(String category) {
  this.category = category;
  }

  @Override
  public String displayDetails() {
  return String.format("EventSeat - %s | Cat:%s | Avail:%s",
  getName(), category, isAvailable());
  }

  @Override
  public String toString() {
  return "EventSeat: " + displayDetails();
  }

  @Override
  public void book(Customer customer) throws ItemNotFoundException {
  if (!isAvailable()) {
  throw new ItemNotFoundException("Seat is already booked: " + getItemID());
  }
  setAvailable(false);
  Reservation r = new Reservation(customer, this);
  customer.addReservation(r);
  }

  @Override
  public void cancelBooking(Customer customer) throws ItemNotFoundException {
  boolean removed = customer.removeReservationForItem(this);
  if (!removed) {
  throw new ItemNotFoundException("No booking found to cancel for item " + getItemID());
  }
  setAvailable(true);
  }
  }
