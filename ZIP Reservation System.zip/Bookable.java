/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package reservation;

/**

* Interface defining booking operations.
  */
  public interface Bookable {
  /**

  * Book the item for the given customer.
  * @param customer customer making the booking
  * @throws ItemNotFoundException if booking cannot be completed (e.g., already booked)
    */
    void book(Customer customer) throws ItemNotFoundException;

  /**

  * Cancel a booking for the given customer.
  * @param customer customer cancelling
  * @throws ItemNotFoundException if cancellation cannot be completed
    */
    void cancelBooking(Customer customer) throws ItemNotFoundException;
    }
