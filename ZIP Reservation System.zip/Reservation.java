/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservation;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 * Reservation record linking a Customer and a ReservableItem.
 */
public class Reservation {

    /** Possible reservation statuses. */
    public enum Status { ACTIVE, CANCELLED, COMPLETED }

    /** Timestamp when reservation was created. */
    private LocalDateTime dateReserved;

    /** Current reservation status. */
    private Status status;

    /** The customer who made the reservation. */
    private Customer customer;

    /** The reserved item. */
    private ReservableItem item;

    /**
     * Constructor creating ACTIVE reservation at current time.
     * @param customer customer
     * @param item item
     */
    public Reservation(Customer customer, ReservableItem item) {
        this.dateReserved = LocalDateTime.now();
        this.status = Status.ACTIVE;
        this.customer = customer;
        this.item = item;
    }

    /** @return reservation time. */
    public LocalDateTime getDateReserved() {
        return dateReserved;
    }

    /** @return status. */
    public Status getStatus() {
        return status;
    }

    /** @param status set status. */
    public void setStatus(Status status) {
        this.status = status;
    }

    /** @return customer. */
    public Customer getCustomer() {
        return customer;
    }

    /** @return item. */
    public ReservableItem getItem() {
        return item;
    }

    @Override
    public String toString() {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        String dt = dateReserved.format(f);
        return String.format("Reservation[%s] ItemID:%s Name:%s By:%s at %s",
                status, item == null ? "null" : item.getItemID(),
                item == null ? "null" : item.getName(),
                customer == null ? "null" : customer.getName(), dt);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Reservation)) return false;
        Reservation that = (Reservation) o;
        return Objects.equals(customer, that.customer) &&
                Objects.equals(item, that.item) &&
                Objects.equals(dateReserved, that.dateReserved);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dateReserved, customer, item);
    }
}
