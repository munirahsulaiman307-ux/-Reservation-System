/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservation;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Represents a customer who can make reservations.
 * Customer composes Reservation objects.
 */
public class Customer implements Cloneable, Comparable<Customer> {

    /** Customer identifier. */
    private Integer id;

    /** Customer name. */
    private String name;

    /** List of reservations for this customer. */
    private List<Reservation> reservations;

    /** Default constructor. */
    public Customer() {
        this.id = null;
        this.name = "";
        this.reservations = new ArrayList<>();
    }

    /**
     * Full constructor.
     * @param id id
     * @param name name
     */
    public Customer(Integer id, String name) {
        this.id = id;
        this.name = name;
        this.reservations = new ArrayList<>();
    }

    /** @return id. */
    public Integer getId() {
        return id;
    }

    /** @param id set id. */
    public void setId(Integer id) {
        this.id = id;
    }

    /** @return name. */
    public String getName() {
        return name;
    }

    /** @param name set name. */
    public void setName(String name) {
        this.name = name;
    }

    /** @return reservations list. */
    public List<Reservation> getReservations() {
        return reservations;
    }

    /** @param r add a reservation. */
    public void addReservation(Reservation r) {
        reservations.add(r);
    }

    /**
     * Remove reservation matching an item (active only).
     * @param item item to remove reservation for
     * @return true if removed
     */
    public boolean removeReservationForItem(ReservableItem item) {
        for (Reservation r : new ArrayList<>(reservations)) {
            if (r.getItem() != null && r.getItem().equals(item) && r.getStatus() == Reservation.Status.ACTIVE) {
                r.setStatus(Reservation.Status.CANCELLED);
                reservations.remove(r);
                return true;
            }
        }
        return false;
    }

    /** @return true if there is any active reservation. */
    public boolean hasActiveReservations() {
        for (Reservation r : reservations) {
            if (r.getStatus() == Reservation.Status.ACTIVE) return true;
        }
        return false;
    }

    @Override
    public Customer clone() {
        try {
            Customer copy = (Customer) super.clone();
            copy.reservations = new ArrayList<>(this.reservations);
            return copy;
        } catch (CloneNotSupportedException e) {
            return new Customer(this.id, this.name);
        }
    }

    @Override
    public String toString() {
        long active = reservations.stream().filter(r -> r.getStatus() == Reservation.Status.ACTIVE).count();
        return String.format("Customer[ID:%s, Name:%s, ActiveReservations:%d]", id, name, active);
    }

    /**
     * Compare customers by id for TreeSet ordering.
     * @param other other customer
     * @return compare result
     */
    @Override
    public int compareTo(Customer other) {
        if (this.id == null && (other == null || other.id == null)) return 0;
        if (this.id == null) return -1;
        if (other == null || other.id == null) return 1;
        return this.id.compareTo(other.id);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Customer)) return false;
        Customer c = (Customer) o;
        return this.id != null && this.id.equals(c.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
